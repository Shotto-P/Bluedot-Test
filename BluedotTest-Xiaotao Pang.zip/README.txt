Bluedot Test
1.how to run the project:
Open in Xcode, build and run, set the simulator feature->locations->freeway drive, so as to letting each movement is greater than 10m. Remember to give access to the location authorization when open the app.

2.Implementation decisions and trade-offs you made:
I decided to build it as an location tracking application, with map view showing, even thought I was asked to keep the app simple, but I still want it to be like this, to let the user feel more clear what the app is doing.

3.Any architectural considerations and reasoning.
Sorry, not sure.

4.Your areas of focus, and anything you would like to draw our attention to.
I really enjoy the process building an app. I would like to learn more and practice more on real commercial products with the professional development team.

5.Any copied code, references and 3rd party libraries
Nothing. 

6.How long you work on the app for
I have created the project on 3/2/2022, I m sorry I have planed hanging out for an road trip during the Spring Festival, I started working on it on 5/2/2022, I have spent a few hours reviewing Swift, searching for tutorials on locationManager, then finished the app within a few hours. But I have spent hours on 6/2/2022 learning how to write unit test on swift and finished it in an hour.

7.Anything else you want us to know
Really looking forwards to having an opportunity to work with you and learn from you..

Best Regards
Xiaotao
