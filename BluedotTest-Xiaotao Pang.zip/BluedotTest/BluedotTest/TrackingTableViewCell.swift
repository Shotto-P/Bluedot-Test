//
//  TrackingTableViewCell.swift
//  BluedotTest
//
//  Created by Shotto Pang on 5/2/22.
//

import UIKit

class TrackingTableViewCell: UITableViewCell {

    @IBOutlet var infoLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
