//
//  ViewController.swift
//  BluedotTest
//
//  Created by Shotto Pang on 3/2/22.
//
import MapKit
import CoreLocation
import UIKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet var historyTable: UITableView!
    @IBOutlet var mapView: MKMapView!
    var locationManager: CLLocationManager!
    var historys = [String]()
    var prevLocation: CLLocation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager = CLLocationManager()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        //checking the authorization status
        switch locationManager.authorizationStatus {
        case .authorizedAlways:
            print("authorizeAlways")
        case .authorizedWhenInUse:
            print("authorizedWhenInUse")
        case .denied:
            print("denied")
        case .notDetermined:
            print("notDetermined")
        case .restricted:
            print("restricted")
        default:
            print("nothing")
        }
        
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.delegate = self
        locationManager.startUpdatingLocation()
        locationManager.startUpdatingHeading()
        
        mapView.delegate = self
        mapView.mapType = .standard
        mapView.isZoomEnabled = true
        mapView.isScrollEnabled = true
        
        mapView.setUserTrackingMode(.follow, animated: true)
        
        historyTable.delegate = self
        historyTable.dataSource = self
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        let userLocation = locations.last!
        let centerCoordinate = CLLocationCoordinate2DMake(userLocation.coordinate.latitude, userLocation.coordinate.longitude)
        let span:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        let region: MKCoordinateRegion = MKCoordinateRegion(center: centerCoordinate, span: span)
        self.mapView.setRegion(region, animated: true)
        
        
        let newLocation = locations.last!
        //print("(\(newLocation.coordinate.latitude), \(newLocation.coordinate.longitude))")
        
        if let oldLocation = self.prevLocation {
            let distance = Double(round(oldLocation.distance(from: newLocation)*10)/10)
            if distance > 10 {
                let log = "You have moved \(distance) meters."
                self.historys.append(log)
                //print(log)
                print("History array:")
                for hist in self.historys {
                    print(hist)
                }
                print("End")
                self.historyTable.reloadData()
                
            }
        } else {
            //nothing
        }
        
        self.prevLocation = newLocation
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error){
        print("Failed \(error)")
    }

    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return historys.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "TrackingTableViewCell", for: indexPath)
        let history  = historys[indexPath.row]
        if let historyCell = cell as? TrackingTableViewCell{
            historyCell.infoLabel.text = history
        }
        
        return cell
    }
}

