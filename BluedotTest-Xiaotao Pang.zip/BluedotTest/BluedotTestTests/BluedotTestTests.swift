//
//  BluedotTestTests.swift
//  BluedotTestTests
//
//  Created by Shotto Pang on 6/2/22.
//

import XCTest
import CoreLocation
@testable import BluedotTest

class BluedotTestTests: XCTestCase {
    var bluedot: ViewController!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        super.setUp()
        bluedot = ViewController()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        bluedot = nil
    }

    func testInitialHistorysIsEmpty(){
        XCTAssertTrue(bluedot.historys.isEmpty)
    }

}
